class ApplicationConfig:
    JSONIFY_PRETTYPRINT_REGULAR = True
    DEBUG = True
    SESSION_PERMANENT = False
    SESSION_TYPE = 'filesystem'
    SECRET_KEY = 'asdfjalkjfewiajf'